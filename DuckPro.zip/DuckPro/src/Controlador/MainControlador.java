package Controlador;

import Modelo.EstadisticaPato;
import Modelo.Participante;
import Vista.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class MainControlador {

    private JFrame frame;

    private MenuForm menu;
    private RegistroForm registro;
    private CrearCarreraForm carrera;
    private CarreraAnimForm carreraAnim;

    private Timer timer; // Usados para la carrera
    private Random random = new Random();

    private boolean carreraValidada = false; // Booleans para el manejo de validaciones
    private boolean carreraActiva = true;

    private int ejeX = 820; // Línea de llegada de los patos

    private List<Participante> listaParticipantes = new ArrayList<>(); // Participantes, estadisticas y podio
    private ArrayList<String> podio = new ArrayList<>();
    private ArrayList<EstadisticaPato> estadisticas = new ArrayList<>();

    private Participante pato1;
    private Participante pato2;
    private Participante pato3;

    private DefaultTableModel modeloTabla;

    public MainControlador(MenuForm menu,
                           RegistroForm registro,
                           CrearCarreraForm carrera,
                           CarreraAnimForm carreraAnim) {

        this.menu = menu;
        this.registro = registro;
        this.carrera = carrera;
        this.carreraAnim = carreraAnim;

        frame = new JFrame("DuckPro");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 700);
        frame.setLocationRelativeTo(null);

        mostrarPanel(menu.getMainPanel());

        modeloTabla = new DefaultTableModel(
                new Object[]{"Nombre", "Edad", "Documento", "Nombre Pato", "Categoría"}, 0);
        registro.tablaParticipantes.setModel(modeloTabla);

        timer = new Timer(50, e -> {
            moverPato(carreraAnim.Pato1);
            moverPato(carreraAnim.Pato2);
            moverPato(carreraAnim.Pato3);

            verificarLlegada(carreraAnim.Pato1, pato1.getNumeroPato());
            verificarLlegada(carreraAnim.Pato2, pato2.getNumeroPato());
            verificarLlegada(carreraAnim.Pato3, pato3.getNumeroPato());
        });

        /* Todos los listeners */

        menu.estadísticasButton.addActionListener(e ->  {
                mostrarEstadisticas();
        });

        menu.registroButton.addActionListener(e ->
                mostrarPanel(registro.getMainPanel()));

        menu.carreraButton.addActionListener(e ->
                mostrarPanel(carrera.getMainPanel()));

        menu.búsquedaDeParticipantesButton.addActionListener(e ->
                buscarParticipante());

        registro.volverButton.addActionListener(e ->
                mostrarPanel(menu.getMainPanel()));

        registro.registrarButton.addActionListener(e -> {
            registrarParticipante();
            registro.nombreField.setText("");
            registro.edadField.setText("");
            registro.documentoField.setText("");
            registro.noPatoField.setText("");
        });

        carrera.volverAlMenuButton.addActionListener(e ->
                mostrarPanel(menu.getMainPanel()));

        carrera.NuevaCarreraButton.addActionListener(e -> {
            if (!validarPatosYCategoria()) return;
            carreraValidada = true;
            mostrarPanel(carreraAnim.getMainPanel());
        });

        carreraAnim.volverAlMenuButton.addActionListener(e -> {
            timer.stop();
            carreraValidada = false;
            mostrarPanel(menu.getMainPanel());
        });

        carreraAnim.iniciarCarreraButton.addActionListener(e -> {
            if (!carreraValidada) {
                JOptionPane.showMessageDialog(frame,
                        "Debe validar la carrera antes de iniciar");
                return;
            }
            reiniciarPatos();
            timer.start();
        });

        frame.setVisible(true);
    }

    /* Para evitar que un panel se ponga encima del otro */

    private void mostrarPanel(JPanel panel) {
        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    /* Registro de participantes (Manejo de la tabla y de la clase) */

    void registrarParticipante() {
        String nombre = registro.nombreField.getText();
        int edad = Integer.parseInt(registro.edadField.getText());
        int documento = Integer.parseInt(registro.documentoField.getText());
        String categoria = registro.categoriaCombo.getSelectedItem().toString();
        String nombrePato = registro.noPatoField.getText();

        Participante participante =
                new Participante(nombre, edad, documento, categoria, nombrePato);

        listaParticipantes.add(participante);
        actualizarTabla();
    }

    void actualizarTabla() {
        modeloTabla.setRowCount(0);
        for (Participante p : listaParticipantes) {
            modeloTabla.addRow(new Object[]{
                    p.getNombre(),
                    p.getEdad(),
                    p.getDocumento(),
                    p.getNumeroPato(),
                    p.getCategoria()
            });
        }
    }

    /* Búsqueda de participantes en el Array List */

    void buscarParticipante() {

        String input = JOptionPane.showInputDialog(
                frame,
                "Ingrese nombre o documento del participante:"
        );

        if (input == null || input.trim().isEmpty()) return;

        for (Participante p : listaParticipantes) {

            if (p.getNombre().equalsIgnoreCase(input.trim()) ||
                    String.valueOf(p.getDocumento()).equals(input.trim())) {

                JOptionPane.showMessageDialog(frame,
                        "Participante encontrado:\n" +
                                "Nombre: " + p.getNombre() + "\n" +
                                "Edad: " + p.getEdad() + "\n" +
                                "Documento: " + p.getDocumento() + "\n" +
                                "Pato: " + p.getNumeroPato() + "\n" +
                                "Categoría: " + p.getCategoria()
                );
                return;
            }
        }

        JOptionPane.showMessageDialog(frame,
                "Participante no encontrado");
    }

    /* Todo lo relacionado a la carrera */

    void reiniciarPatos() {
        podio.clear();
        carreraActiva = true;

        carreraAnim.Pato1.setLocation(10, carreraAnim.Pato1.getY());
        carreraAnim.Pato2.setLocation(10, carreraAnim.Pato2.getY());
        carreraAnim.Pato3.setLocation(10, carreraAnim.Pato3.getY());
    }

    void moverPato(JLabel pato) {
        pato.setLocation(pato.getX() + random.nextInt(10), pato.getY());
    }

    void verificarLlegada(JLabel pato, String nombrePato) {
        if (pato.getX() >= ejeX && !podio.contains(nombrePato)) {
            podio.add(nombrePato);
        }
        if (podio.size() == 3) finalizarCarrera();
    }

    void finalizarCarrera() {
        if (!carreraActiva) return;

        timer.stop();
        carreraActiva = false;
        carreraValidada = false;

        JOptionPane.showMessageDialog(frame,
                "Primer lugar: " + podio.get(0) + "\n" +
                        "Segundo lugar: " + podio.get(1) + "\n" +
                        "Tercer lugar: " + podio.get(2),
                "Podio", JOptionPane.INFORMATION_MESSAGE);

        guardarResultadoTXT();

        EstadisticaPato e1 = obtenerEstadistica(podio.get(0));
        EstadisticaPato e2 = obtenerEstadistica(podio.get(1));
        EstadisticaPato e3 = obtenerEstadistica(podio.get(2));

        e1.sumarParticipacion();
        e2.sumarParticipacion();
        e3.sumarParticipacion();

        e1.sumarVictoria();

    }

    void guardarResultadoTXT() {
        if (podio.size() < 3) return;

        try (PrintWriter writer = new PrintWriter(new FileWriter("resultados.txt", true))) {
            writer.println("Carrera: " + carrera.nombreCarreraField.getText());
            writer.println("Fecha: " + LocalDate.now());
            writer.println("Categoría: " + carrera.categoriaCombo.getSelectedItem());
            writer.println("Resultados:");
            writer.println("Primer lugar: " + podio.get(0));
            writer.println("Segundo lugar: " + podio.get(1));
            writer.println("Tercer lugar: " + podio.get(2));
            writer.println("-----------------------------------");
            writer.println();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame,
                    "Error al guardar resultados: " + e.getMessage());
        }
    }

    /* Validaciones antes de la carrera */

    public Participante buscarPorNombrePato(String nombrePato) {
        for (Participante p : listaParticipantes) {
            if (p.getNumeroPato().equalsIgnoreCase(nombrePato.trim())) {
                return p;
            }
        }
        return null;
    }

    public boolean validarPatosYCategoria() {

        String p1 = carrera.Pato1Field.getText().trim();
        String p2 = carrera.Pato2Field.getText().trim();
        String p3 = carrera.Pato3Field.getText().trim();

        if (p1.isEmpty() || p2.isEmpty() || p3.isEmpty()) {
            JOptionPane.showMessageDialog(frame,
                    "Debe ingresar los 3 patos");
            return false;
        }

        pato1 = buscarPorNombrePato(p1);
        pato2 = buscarPorNombrePato(p2);
        pato3 = buscarPorNombrePato(p3);

        if (pato1 == null || pato2 == null || pato3 == null) {
            JOptionPane.showMessageDialog(frame,
                    "Uno o más patos no están registrados");
            return false;
        }

        if (pato1 == pato2 || pato1 == pato3 || pato2 == pato3) {
            JOptionPane.showMessageDialog(frame,
                    "No se pueden repetir patos");
            return false;
        }

        String categoria = carrera.categoriaCombo.getSelectedItem().toString();

        if (!pato1.getCategoria().equalsIgnoreCase(categoria) ||
                !pato2.getCategoria().equalsIgnoreCase(categoria) ||
                !pato3.getCategoria().equalsIgnoreCase(categoria)) {

            JOptionPane.showMessageDialog(frame,
                    "Todos los patos deben ser de la categoría " + categoria);
            return false;
        }

        JOptionPane.showMessageDialog(frame,
                "Carrera validada correctamente");
        return true;
    }

    /* Estadísticas del pato */

    public EstadisticaPato obtenerEstadistica(String nombrePato) {

        for (EstadisticaPato e : estadisticas) {
            if (e.getNombrePato().equalsIgnoreCase(nombrePato)) {
                return e;
            }
        }

        EstadisticaPato nueva = new EstadisticaPato(nombrePato);
        estadisticas.add(nueva);
        return nueva;
    }

    public void mostrarEstadisticas() {

        if (estadisticas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay estadísticas registradas");
            return;
        }

        StringBuilder mensaje = new StringBuilder("ESTADÍSTICAS DE LOS PATOS\n\n");

        for (EstadisticaPato e : estadisticas) {
            mensaje.append("Pato: ").append(e.getNombrePato()).append("\n");
            mensaje.append("Carreras ganadas: ").append(e.getGanadas()).append("\n");
            mensaje.append("Carreras participadas: ").append(e.getParticipadas()).append("\n");
            mensaje.append("----------------------------\n");
        }

        JOptionPane.showMessageDialog(null, mensaje.toString());
    }

}
