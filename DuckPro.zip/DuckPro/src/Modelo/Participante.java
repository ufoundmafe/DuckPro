package Modelo;

public class Participante {

    String nombre;
    int edad;
    int documento;
    String categoria;
    String noPato;

    public Participante(String nombre, int edad, int documento, String categoria, String noPato) {
        this.nombre = nombre;
        this.edad = edad;
        this.documento = documento;
        this.categoria = categoria;
        this.noPato = noPato;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getDocumento() {
        return documento;
    }

    public void setDocumento(int documento) {
        this.documento = documento;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getNumeroPato() {
        return noPato;
    }

    public void setNumeroPato(String noPato) {
        this.noPato = noPato;
    }
}
