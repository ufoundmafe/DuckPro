package Modelo;

import java.time.LocalDate;

public class Carrera {

    String nombre;
    String categoria;
    LocalDate fecha;

    public Carrera(String nombre, String categoria, LocalDate fecha) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.fecha = fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
}
