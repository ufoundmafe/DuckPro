package Modelo;

public class EstadisticaPato {

    String nombrePato;
    int ganadas;
    int participadas;

    public EstadisticaPato(String nombrePato) {
        this.nombrePato = nombrePato;
        this.ganadas = 0;
        this.participadas = 0;
    }

    public void sumarParticipacion() {
        participadas++;
    }

    public void sumarVictoria() {
        ganadas++;
    }

    public String getNombrePato() {
        return nombrePato;
    }

    public int getGanadas() {
        return ganadas;
    }

    public int getParticipadas() {
        return participadas;
    }
}
