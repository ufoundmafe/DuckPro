package Modelo;

import Vista.MenuForm;
import Vista.RegistroForm;
import Vista.CrearCarreraForm;
import Vista.CarreraAnimForm;

import Controlador.MainControlador;

import javax.swing.*;

public class App {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Gestor de Carreras");

        MenuForm menu = new MenuForm();
        RegistroForm registro = new RegistroForm();
        CrearCarreraForm carrera = new CrearCarreraForm();
        CarreraAnimForm carreraAnim = new CarreraAnimForm();

        MainControlador controlador = new MainControlador(menu, registro, carrera, carreraAnim);

        frame.setContentPane(menu.getMainPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setSize(900, 700);
        frame.setLocationRelativeTo(null);

    }
}
