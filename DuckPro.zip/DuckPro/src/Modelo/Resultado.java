package Modelo;

public class Resultado {

    String nombre;
    String primerPuesto;
    String segundoPuesto;
    String tercerPuesto;
    int duracion;

    public Resultado(String nombre, String primerPuesto, String segundoPuesto, String tercerPuesto, int duracion) {
        this.nombre = nombre;
        this.primerPuesto = primerPuesto;
        this.segundoPuesto = segundoPuesto;
        this.tercerPuesto = tercerPuesto;
        this.duracion = duracion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPrimerPuesto() {
        return primerPuesto;
    }

    public void setPrimerPuesto(String primerPuesto) {
        this.primerPuesto = primerPuesto;
    }

    public String getSegundoPuesto() {
        return segundoPuesto;
    }

    public void setSegundoPuesto(String segundoPuesto) {
        this.segundoPuesto = segundoPuesto;
    }

    public String getTercerPuesto() {
        return tercerPuesto;
    }

    public void setTercerPuesto(String tercerPuesto) {
        this.tercerPuesto = tercerPuesto;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
}
