package Vista;

import javax.swing.*;

public class CrearCarreraForm {
    public JPanel mainPanel;
    public JButton NuevaCarreraButton;
    public JTextField Pato1Field;
    public JTextField Pato2Field;
    public JTextField Pato3Field;
    public JComboBox categoriaCombo;
    public JTextField nombreCarreraField;
    public JButton volverAlMenuButton;

    public CrearCarreraForm() {


    }

    public JPanel getMainPanel(){
        return mainPanel; // Panel del catálogo
    }
}

