package Vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuForm {
    public JPanel mainPanel;
    public JButton registroButton;
    public JButton carreraButton;
    public JButton estadísticasButton;
    public JButton búsquedaDeParticipantesButton;

    public MenuForm() {

    }
    public JPanel getMainPanel(){
        return mainPanel; // Panel del catálogo
    }
}
