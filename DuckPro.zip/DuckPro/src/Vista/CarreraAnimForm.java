package Vista;

import javax.swing.*;

public class CarreraAnimForm {
    public JPanel mainPanel;
    public JLabel Pato1;
    public JLabel Pato2;
    public JLabel Pato3;
    public JButton iniciarCarreraButton;
    public JButton volverAlMenuButton;

    public CarreraAnimForm() {

    }

    public JPanel getMainPanel() {
        return mainPanel;
    }
}
