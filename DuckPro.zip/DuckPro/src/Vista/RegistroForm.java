package Vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegistroForm {
    public JPanel mainPanel;
    public JTextField nombreField;
    public JTextField edadField;
    public JTextField documentoField;
    public JTextField noPatoField;
    public JButton registrarButton;
    public JComboBox categoriaCombo;
    public JTable tablaParticipantes;
    public JButton volverButton;

    public RegistroForm() {

        volverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }

    public JPanel getMainPanel(){
        return mainPanel; // Panel del catálogo
    }
}
